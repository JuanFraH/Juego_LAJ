import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class BalaCañon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class BalaCañon extends Actor
{
    public boolean der;
    public BalaCañon(){
        setImage("BalaCañon.png");
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*3/2;
        int myNewWidth = (int)myImage.getWidth()*3/2;
        myImage.scale(myNewWidth,myNewHeight);
    }
    
    
    public void act()
    {
        if (der == true){
            setLocation(getX()+5, getY()-5);
        }
        else{
            setLocation(getX()-5, getY()-5);
        }
        
        
        Actor Frasco;
        Actor Rocas;
        Frasco = getOneObjectAtOffset(0,0,Frasco.class);
        Rocas = getOneObjectAtOffset(0,0,Rocas.class);
        Escenario escenario = (Escenario) getWorld();
        
        if (getY() <= 0){
            escenario.removeObject(this);
        }
        
        if (Rocas != null){
            escenario.removeObject(this);
        }
        if (Frasco != null){
            escenario.removeObject(Frasco);
            escenario.removeObject(this);
            escenario.ptos();
        }
    }
}
