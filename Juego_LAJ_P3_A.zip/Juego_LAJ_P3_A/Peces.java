import greenfoot.*; 

public class Peces extends Actor
{
    int obj = Greenfoot.getRandomNumber(6);
    
    public Peces(){
        switch (obj){
            case 0:
                setImage("Peza.png");
                break;
            case 1:
                setImage("Pezr.png");
                break;
            case 2:
                setImage("Pezv.png");
                break;
            case 3:
                setImage("Pezn.png");
                break;
            case 4:
                setImage("Pezm.png");
                break;
            case 5:
                setImage("Pezb.png");
                break;
        }
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*5/8;
        int myNewWidth = (int)myImage.getWidth()*5/8;
        myImage.scale(myNewWidth,myNewHeight);
    }
    int x = Greenfoot.getRandomNumber(2);
    int a;
    int b = 0;
    int c= 0;
    boolean imagenReflejada = false;
    public void act()
    {
      switch (x) {
        case 0:
            
            if (b==0) {
                a = 2;
            }
            break;
        case 1:
            if (!imagenReflejada) {
                getImage().mirrorHorizontally(); 
                imagenReflejada = true; 
            }
            if (c==0) {
                a = -2;
            }
            break;
    }

    setLocation(getX() + a, getY());
    if (getX() == 886 || getX() == 885) {
        a = -a;
        b = 1;
        c= 0;
        getImage().mirrorHorizontally();
    }

    if (getX() == 14 || getX() == 15) {
        a = -a;
        b = 0;
        c = 1;
        getImage().mirrorHorizontally();
    }
}
    }