import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Flecha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Flecha extends Actor
{
    public Flecha(){
        setImage("Flecha.png");
        
        
    }
    public void act()
    {
        // Add your action code here.
    }
}
