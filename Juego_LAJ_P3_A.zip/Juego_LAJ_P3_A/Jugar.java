import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Jugar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Jugar extends Actor
{
    public Jugar(){
        setImage("Jugar.png");
        
    }
    public void act()
    {
        // Add your action code here.
    }
}
