import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Menú_inicio here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menú_inicio extends World
{
    Flecha flecha= new Flecha();
    private int opcion=0; //0 = jugar 1 = Salir
    public Menú_inicio()
    {    
        super(900, 600, 1); 
        setBackground("Menu_Inicio");
        prepararMundo();
    }
    
    private void prepararMundo(){
        addObject(new Jugar(),400,250);
        addObject(new Salir(),400,350);
        addObject(flecha,275,250);
    }
    
    
    public void act(){
        Greenfoot.setWorld(new Menú_inicio());
        
        if (Greenfoot.isKeyDown("W") && opcion!=0) {opcion++;}
        if (Greenfoot.isKeyDown("S") && opcion!=1) {opcion--;}
        
        if (opcion>=2) opcion=0;
        if(opcion<0) opcion=1;
        
        flecha.setLocation(275,250 +(opcion*100));
        
        if (Greenfoot.isKeyDown("ENTER")){
            switch(opcion){
                case 0: //jugar
                    Greenfoot.setWorld(new Escenario());
                    break;
                case 1: // salir
                    Greenfoot.stop();
                    break;
            }
        }
        
    }
    }