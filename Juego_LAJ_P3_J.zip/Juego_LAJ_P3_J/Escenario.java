import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Escenario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Escenario extends World
{
        Gancho gancho = new Gancho();
        private int timeElapsed;
        private int timeCounter;
        private A_Ship ship1;
    public Escenario()
    {    
        super(900, 600, 1); 
        setBackground("tile.png");
    }
    
    public void started() {
        int xpeza;
        xpeza = Greenfoot.getRandomNumber(860) + 20;
        Peces peza = new Peces();
        addObject(peza,xpeza,400);
        
        int xpezr;
        xpezr = Greenfoot.getRandomNumber(860) + 20;
        Peces pezr = new Peces();
        addObject(pezr,xpezr, 450);
        
        int xpezv;
        xpezv = Greenfoot.getRandomNumber(860) + 20;
        Peces pezv = new Peces();
        addObject(pezv,xpezv,500);
        
        int xpezn;
        xpezn = Greenfoot.getRandomNumber(860) + 20;
        Peces pezn = new Peces();
        addObject(pezn,xpezn,550);
        
        int xpezm;
        xpezm = Greenfoot.getRandomNumber(860) + 20;
        Peces pezm = new Peces();
        addObject(pezm,xpezm,479);
        
        int xpezb;
        xpezb = Greenfoot.getRandomNumber(860) + 20;
        Peces pezb = new Peces();
        addObject(pezb,xpezb,562);
        
        int ypeza;
        ypeza = Greenfoot.getRandomNumber(860) + 20;
        Peces pezay = new Peces();
        addObject(pezay,ypeza,424);
        
        int ypezr;
        ypezr = Greenfoot.getRandomNumber(860) + 20;
        Peces pezry = new Peces();
        addObject(pezry,ypezr, 458);
        
        int ypezv;
        ypezv = Greenfoot.getRandomNumber(860) + 20;
        Peces pezvy = new Peces();
        addObject(pezvy,ypezv,512);
        
        int ypezn;
        ypezn = Greenfoot.getRandomNumber(860) + 20;
        Peces pezny = new Peces();
        addObject(pezny,ypezn,582);
        
        int ypezm;
        ypezm = Greenfoot.getRandomNumber(860) + 20;
        Peces pezmy = new Peces();
        addObject(pezmy,ypezm,590);
        
        int ypezb;
        ypezb = Greenfoot.getRandomNumber(860) + 20;
        Peces pezby = new Peces();
        addObject(pezby,ypezb,523);
        
        
        int xalgaa2;
        xalgaa2 = Greenfoot.getRandomNumber(900);
        Algas algaa2 = new Algas();
        addObject(algaa2,xalgaa2,580);
        
        int xalgam;
        xalgam = Greenfoot.getRandomNumber(900);
        Algas algam = new Algas();
        addObject(algam,xalgam,580);
        
        int xalgam2;
        xalgam2 = Greenfoot.getRandomNumber(900);
        Algas algam2 = new Algas();
        addObject(algam2,xalgam2,580);
        
        int xalgav;
        xalgav = Greenfoot.getRandomNumber(900);
        Algas algav = new Algas();
        addObject(algav,xalgav,580);
        
        int xalgav2;
        xalgav2 = Greenfoot.getRandomNumber(900);
        Algas algav2 = new Algas();
        addObject(algav2,xalgav2,580);
        
        int yalgaa;
        yalgaa = Greenfoot.getRandomNumber(900);
        Algas algaay = new Algas();
        addObject(algaay,yalgaa,580);
        
        int yalgaa2;
        yalgaa2 = Greenfoot.getRandomNumber(900);
        Algas algaa2y = new Algas();
        addObject(algaa2y,yalgaa2,580);
        
        int yalgam;
        yalgam = Greenfoot.getRandomNumber(900);
        Algas algamy = new Algas();
        addObject(algamy,yalgam,580);
        
        int xalgaa;
        xalgaa = Greenfoot.getRandomNumber(900);
        Algas algaa = new Algas();
        addObject(algaa,xalgaa,580);
        
        ship1 = new A_Ship();
        addObject(ship1,450,500);
        
        addObject(tiempo, 50, 50);
        
        actCounter = new Counter("Puntos: ");
        addObject(actCounter, 800, 30);
    }
    private Counter actCounter;
    int timerspawn;
    int x = Greenfoot.getRandomNumber(4);
    
    private final int FPS = 60;
    private Tiempo tiempo = new Tiempo();
    private int[] hora = {0, 0}; 
    private int timer = 0;
    int segundos;
    public void act(){
        
          switch (x){
            case 0:
                timerspawn = 55;
                break;
            case 1:
                timerspawn = 68;
                break;
            case 2:
                timerspawn = 82;
                break;
            case 3:
                timerspawn = 96;
                break;
        }
        
        int roca;
        int corazon;
        timeCounter = (timeCounter+1)%(timerspawn);
        if (timeCounter == 0)
        {
            timeElapsed++;
            frasco();
            roca = Greenfoot.getRandomNumber(4);
            if (roca < 4){
                roca();
            }
            corazon = Greenfoot.getRandomNumber(5);
            if (corazon == 0){
                Corazón();
            }
            timeElapsed = 0;
            x = Greenfoot.getRandomNumber(4);   
        }
        

        if (++timer==FPS)
        {
           timer = 0;
           if (++hora[1]==60)
           {
               if (++hora[0]==24)
               {
                   hora[0]=0;
               }
               hora[1]=0;
           }
           tiempo.updateImage();
        }
    }
    
    public A_Ship getBarco(){
        return ship1;
    }
    int xfrasco;
    
    private void frasco(){
        xfrasco = Greenfoot.getRandomNumber(840) + 30;
        Frasco frasco1 = new Frasco();
        addObject(frasco1,xfrasco,0);
    }
    int xroca;
    private void roca(){
        xroca = Greenfoot.getRandomNumber(900);
        Rocas roca1 = new Rocas();
        while (xfrasco <= xroca + 100 && xfrasco >= xroca -100){
            xroca = Greenfoot.getRandomNumber(900);
        }
        addObject(roca1,xroca,0);
    }
    int probbonus;
    
    int xCorazón;
    int xPerla;
    private void Corazón(){
        xCorazón = Greenfoot.getRandomNumber(900);
        Corazón Corazón1 = new Corazón();
        Perla Perla1 = new Perla();
        while (xfrasco <= xCorazón + 200 && xfrasco >= xCorazón -200 || xroca <= xCorazón + 200 && xroca >= xCorazón -200){
            xCorazón = Greenfoot.getRandomNumber(900);
        }
        probbonus = Greenfoot.getRandomNumber(4);
        if (probbonus == 0){
            addObject(Perla1,xCorazón,0);
        }
        else{
            addObject(Corazón1,xCorazón,0);
        }
        
    }
    public int ptos;
    public void ptos(){
        actCounter.setValue(actCounter.getValue() + 1);
        ptos++;
    }
    
    public class Tiempo extends Actor {
        public Tiempo() {
            segundos = 0; 
            updateImage(); 
        }

        public void act() {
            segundos++;
            updateImage();
        }

        public void updateImage() {
            int horas = segundos / 3600;
            int minutos = (segundos % 3600) / 60;
            int segs = segundos % 60;

            String h = (horas < 10) ? "0" + horas : "" + horas;
            String m = (minutos < 10) ? "0" + minutos : "" + minutos;
            String s = (segs < 10) ? "0" + segs : "" + segs;

            GreenfootImage img = new GreenfootImage(65,40);
            Color colorPersonalizado = new Color(1, 16, 120);
            img.setColor(colorPersonalizado);
            img.setFont(new Font("Calibri", 25));
            img.drawString(h + ":" + m + ":" + s, 5, 20);
            setImage(img);
        }
    }
}