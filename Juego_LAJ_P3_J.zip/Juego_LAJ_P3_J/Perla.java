import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Perla here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Perla extends Actor
{
    public Perla(){
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*3/8;
        int myNewWidth = (int)myImage.getWidth()*3/8;
        myImage.scale(myNewWidth,myNewHeight);
    }
    /**
     * Act - do whatever the Perla wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        setLocation(getX(), getY() + 2);
        if (isAtEdge()){
            getWorld().removeObject(this);
        }
    }
}
