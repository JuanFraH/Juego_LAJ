import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Escenario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Escenario extends World
{
    // https://www.greenfoot.org/topics/63600/0
    Gancho gancho = new Gancho();
    int frames;
    boolean set, go;
    public Escenario()
    {    
        super(900, 600, 1); 
        setBackground("tile.png");
    }
    
    public void started() {
        Ship ship1 = new Ship();
        addObject(ship1,450,500);
        botella();
        frasco();
    }
    
    int millis = (int)(System.currentTimeMillis()%1000);
    public void act(){
        if (Greenfoot.isKeyDown("space") && gancho.e == false){
            gancho();
            gancho.e = true;
        }
        
        if (!set && !go){
            if (millis > 100) set = true;
            return;
        }
        if (set && !go){ 
            if (millis < 100) { go = true; set = false; } 
            return;
        }
        
        frames++; 
        if (!set && go){
            if (millis > 100) set = true;
            return;
        }
        if (set && go){
            if (millis < 100){
                set = false; 
                frames = 0; 
            }
        }
    }
    
    private void botella(){
        int xbotella;
        xbotella = Greenfoot.getRandomNumber(900);
        Botella botella1 = new Botella();
        addObject(botella1,xbotella,0);
    }

    private void frasco(){
        int xfrasco;
        xfrasco = Greenfoot.getRandomNumber(900);
        Frasco frasco1 = new Frasco();
        addObject(frasco1,xfrasco,0);
    }
    
    private void gancho(){
        int xgancho;
        xgancho = Greenfoot.getRandomNumber(900);
        Gancho gancho1 = new Gancho();
        addObject(gancho1,xgancho,500);
    }
    
}
