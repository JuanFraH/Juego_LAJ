import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Ship here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ship extends Actor
{
    public Ship(){
        setImage("ship.png");
    }

    public void act()
    {
        setRotation(180);
        
        if (Greenfoot.isKeyDown("A")){
            move (3);
        }
        if (Greenfoot.isKeyDown("D")){
            move (-3);
        }
    }
}
