import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gancho here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gancho extends Actor
{
    public boolean e = false;
    public Gancho(){
        setImage("Ancla.png");
        setRotation(180);
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*1/8;
        int myNewWidth = (int)myImage.getWidth()*1/8;
        myImage.scale(myNewWidth,myNewHeight);
    }
    
    public void act()
    {
        setLocation(getX(), getY() - 5);
        if (isAtEdge()){
            getWorld().removeObject(this);
            e = false;
        }
    }
}
