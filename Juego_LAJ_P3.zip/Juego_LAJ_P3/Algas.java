import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Algas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Algas extends Actor
{
    int obj = Greenfoot.getRandomNumber(13);
    
    public Algas(){
        switch (obj){
            case 0:
                setImage("Algaa.png");
                break;
            case 1:
                setImage("Algaa2.png");
                break;
            case 2:
                setImage("Algam.png");
                break;
            case 3:
                setImage("Algam2.png");
                break;
            case 4:
                setImage("Algav2.png");
                break;
            case 5:
                setImage("Algav2.png");
                break;
        }
        GreenfootImage myImage = getImage();
        int myNewHeight = (int)myImage.getHeight()*5/8;
        int myNewWidth = (int)myImage.getWidth()*5/8;
        myImage.scale(myNewWidth,myNewHeight);
    }
    
}