import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Escenario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Escenario extends World
{

    /**
     * Constructor for objects of class Escenario.
     * 
     */
    public Escenario()
    {    
        super(600, 400, 1); 
        setBackground("tile.png");
    }
    
    public void started() {
        
        Ship ship1 = new Ship();
        addObject(ship1,300,300);
    }
}
